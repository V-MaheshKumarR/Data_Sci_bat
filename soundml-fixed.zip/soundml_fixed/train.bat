@echo off
REM ─────────────────────────────────────────────────────────────────────────
REM  SoundML — Train Only (Windows)
REM  Run this first if you just want to generate the model files.
REM ─────────────────────────────────────────────────────────────────────────
cd /d "%~dp0"

echo.
echo ================================================
echo   SoundML — Model Training
echo ================================================

REM Install dependencies if needed
pip install scikit-learn numpy pandas joblib 2>nul

REM Run training — uses --no-tune for speed (remove for full GridSearchCV)
python backend\ml\train.py --no-tune

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Training failed. Full error shown above.
    pause
    exit /b 1
)

echo.
echo [OK] Training complete!  Model saved to backend\ml\models\
echo      Now run:  run_server.bat
pause
