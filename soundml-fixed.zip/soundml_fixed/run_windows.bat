@echo off
REM ─────────────────────────────────────────────────────────────────────────
REM  SoundML — Windows Quick Start
REM  Double-click this file, or run it from any terminal.
REM  It does NOT require you to cd into any specific folder first.
REM ─────────────────────────────────────────────────────────────────────────

REM Change to the directory where THIS batch file lives (the project root)
cd /d "%~dp0"

echo.
echo ================================================
echo   SoundML — Installing dependencies
echo ================================================
pip install scikit-learn numpy pandas joblib fastapi uvicorn pydantic 2>nul
if %errorlevel% neq 0 (
    echo [WARN] pip install had warnings — continuing anyway
)

echo.
echo ================================================
echo   Step 1/2 — Training models
echo ================================================
python backend\ml\train.py --no-tune
if %errorlevel% neq 0 (
    echo [ERROR] Training failed. See error above.
    pause
    exit /b 1
)

echo.
echo ================================================
echo   Step 2/2 — Starting API server
echo   Open your browser: http://localhost:8000/docs
echo ================================================
python -m uvicorn backend.api.main:app --host 0.0.0.0 --port 8000 --reload

pause
